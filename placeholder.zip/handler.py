# Placeholder Lambda function code for deployment via Terraform
def handler(event, context):
    raise Exception('Lambda function code has not been uploaded')
